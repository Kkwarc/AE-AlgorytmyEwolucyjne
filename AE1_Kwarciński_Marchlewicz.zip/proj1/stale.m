function [a, b, X1, Y1, X2, Y2, X3, Y3, X4, Y4] = stale()
    a = -1;
    b = -1.5;
    X1 = 1;
    Y1 = -0.5;
    X2 = 0;
    Y2 = -2.5;
    X3 = -2;
    Y3 = -2.5;
    X4 = -2;
    Y4 = -0.5;
end